#include <cs50.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

bool only_digits(string key);
string rotate(string text, int key);

int main(int argc, string argv[])
{
    // check if one argument
    if (argc == 1)
    {
        printf("Usage: ./caesar key\n");
        return 1;
    }
    // check if more than one argument
    else if (argc > 2)
    {
        printf("Usage: ./caesar key\n");
        return 1;
    }
    else if (argc == 2)
    {
        // check if digit
        if (only_digits(argv[1]) == false)
        {
            printf("Usage: ./caesar key\n");
            return 1;
        }
    }
    else
    {
        printf("Usage: ./caesar key\n");
    }

    // set up the key
    string key = argv[1];
    int k = atoi(key);
    // get plain text
    string plaintext = get_string("plaintext: ");
    // cipher text
    string ciphertext = rotate(plaintext, k);
    // print ciphered message
    printf("ciphertext: %s\n", ciphertext);
}

bool only_digits(string key)
{
    for (int i = 0, len = strlen(key); i < len; i++)
    {
        // check if it's not a digit
        if (!isdigit(key[i]))
        {
            return false;
        }
        else
        {
        }
    }
    return true;
}

string rotate(string text, int key)
{
    // set char array
    static char coded_string[1000];
    for (int i = 0, len = strlen(text); i < len; i++)
    {
        // check if it's upper case
        if (isupper(text[i]))
        {
            coded_string[i] = ((text[i] - 'A' + key) % 26) + 'A';
        }
        // check if it's lower case
        else if (islower(text[i]))
        {
            coded_string[i] = ((text[i] - 'a' + key) % 26) + 'a';
        }
        // other non alphabetical char
        else
        {
            coded_string[i] = text[i];
        }
    }
    return coded_string;
}
