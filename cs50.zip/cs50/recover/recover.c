#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

// set the size of the buffer
const int jpg_size = 512;

int main(int argc, char *argv[])
{
    // check if only two arguments were passed
    if (argc != 2)
    {
        printf("Usage: ./recover file");
        return 1;
    }

    // open file and check if it opens
    FILE *file = fopen(argv[1], "rb");
    if (file == NULL)
    {
        printf("Could not open the file");
        return 0;
    }

    uint8_t data[jpg_size];
    char file_name[8];
    int jpg_name = 0;
    FILE *img = NULL;

    // read bytes from the card
    while (fread(data, 1, 512, file) == 512)
    {
        // check file headers
        if (data[0] == 0xff && data[1] == 0xd8 && data[2] == 0xff && (data[3] & 0xf0) == 0xe0)
        {
            // check if file is empty
            if (img != NULL)
            {
                fclose(img);
            }
            // create jpg
            sprintf(file_name, "%03d.jpg", jpg_name++);
            img = fopen(file_name, "wb");
        }
        // contiune wiritng into the file
        if (img != NULL)
        {
            fwrite(data, 1, 512, img);
        }
    }
    if (img != NULL)
    {
        fclose(img);
    }

    fclose(file);
    return 0;
}
