#include <cs50.h>
#include <ctype.h>
#include <stdio.h>
#include <string.h>

int count_points(string word);

// set points
int points[27] = {1, 3, 3, 2, 1, 4, 2, 4, 1, 8, 5, 1, 3, 1, 1, 3, 10, 1, 1, 1, 1, 4, 4, 8, 4, 10};

int main(void)
{
    // get strings from players

    string player1 = get_string("Player 1 enter your word: ");
    string player2 = get_string("Player 2 enter your word: ");

    // count scores
    int player1_score = count_points(player1);
    int player2_score = count_points(player2);

    // check who won and print a message

    if (player1_score > player2_score)
    {
        printf("Player 1 wins!!!\n");
    }
    else if (player1_score < player2_score)
    {
        printf("Player 2 wins!!!\n");
    }
    else if (player1_score == player2_score)
    {
        printf("Tie!\n");
    }
}

int count_points(string word)
{
    // set starting score
    int score = 0;
    // count points
    for (int i = 0, len = strlen(word); i <= len; i++)
    {
        // check if it's a letter
        if (isalpha(word[i]))
        {
            if (islower(word[i]))
            {
                score = score + points[word[i] - 'a'];
            }
            else if (isupper(word[i]))
            {
                score = score + points[word[i] - 'A'];
            }
            else
            {
                return 0;
            }
        }
    }
    return score;
}
