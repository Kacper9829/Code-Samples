default_categories = [
    "Food",
    "Transport",
    "Housing",
    "Utilities",
    "Entertainment",
    "Healthcare",
    "Education",
    "Clothing",
    "Insurance",
    "Other"
]