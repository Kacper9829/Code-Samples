SELECT AVG(energy) FROM songs WHERE artist_id = (SELECT name FROM artists WHERE name = "Drake");
