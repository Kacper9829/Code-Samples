SELECT name FROM songs WHERE name LIKE "%feat%";
