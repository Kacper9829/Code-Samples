
class Credit:
    def __init__(self):
        self.credit_card_number = ""
        self.card_type = " "

    # gets user input
    def get_credit_card_number(self):
        try:
            credit_card_number = int(input("Input your credit card number: "))
            return credit_card_number
        # check if input is int
        except ValueError:
            print("Invalid input. Please try again.")
            return None

    # card type check
    def check_card_type(self, credit_card_number):

        if ((credit_card_number >= 34e13 and credit_card_number < 35e13) or
                (credit_card_number >= 37e13 and credit_card_number < 38e13)):

            self.card_type = "AMEX\n"

        elif (credit_card_number >= 51e14 and credit_card_number < 56e14):

            self.card_type = "MASTERCARD\n"

        elif ((credit_card_number >= 4e12 and credit_card_number < 5e12) or
                (credit_card_number >= 4e15 and credit_card_number < 5e15)):

            self.card_type = "VISA\n"

        else:

            self.card_type = "INVALID\n"

        return self.card_type

    def check_if_valid(self, credit_card_number):

        total = 0
        copy = credit_card_number
        # sum every other digit from the last digit
        while copy > 0:
            total += copy % 10
            copy //= 100

        copy = credit_card_number // 10
        # sum double of every other digit starting from 2nd to last
        while copy > 0:
            digit = copy % 10
            double = digit * 2
            total += (double % 10) + (double // 10)
            copy //= 100

        # check total modulo
        return (total % 10 == 0)

    def main(self):
        # get credit card number from the user
        number = self.get_credit_card_number()
        # check card no. length
        card_no_length = len(str(number))
        # check if length is valid
        if (card_no_length == 15 or card_no_length == 16 or card_no_length == 13):
            # run Luhn algorithm
            if self.check_if_valid(number):
                # if valid print type
                print(self.check_card_type(number))
            else:
                print("INVALID\n")
        else:
            print("INVALID\n")


c = Credit()
c.main()
