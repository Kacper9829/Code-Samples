#include <cs50.h>
#include <stdio.h>
#include <string.h>

bool check_if_valid(long long credit_card_number);
string check_what_type(long long credit_card_number);
int check_length(long long credit_card_number);

int main(void)
{
    long long credit_card_number;

    do
    {
        credit_card_number = get_long("Input your credit card number: ");
    }
    while (credit_card_number <= 0);

    string type = check_what_type(credit_card_number);
    int card_no_length = check_length(credit_card_number);

    if (card_no_length == 15 || card_no_length == 16 || card_no_length == 13)
    {
        if (check_if_valid(credit_card_number))
        {
            printf("%s", type);
        }
        else
        {
            printf("INVALID\n");
        }
    }
    else
    {
        printf("INVALID\n");
    }
}

string check_what_type(long long credit_card_number)
{
    string card_type = "";
    if ((credit_card_number >= 34e13 && credit_card_number < 35e13) ||
        (credit_card_number >= 37e13 && credit_card_number < 38e13))
    {
        card_type = "AMEX\n";
    }
    else if (credit_card_number >= 51e14 && credit_card_number < 56e14)
    {
        card_type = "MASTERCARD\n";
    }
    else if ((credit_card_number >= 4e12 && credit_card_number < 5e12) ||
             (credit_card_number >= 4e15 && credit_card_number < 5e15))
    {
        card_type = "VISA\n";
    }
    else
    {
        card_type = "INVALID\n";
    }
    return card_type;
}

bool check_if_valid(long long credit_card_number)
{
    int sum = 0;
    long long copy_c_c_n = credit_card_number;

    while (copy_c_c_n > 0)
    {
        int last_digit = copy_c_c_n % 10;
        sum += last_digit;
        copy_c_c_n /= 100;
    }

    copy_c_c_n = credit_card_number / 10;
    while (copy_c_c_n > 0)
    {
        int digit = copy_c_c_n % 10;
        int times_2 = digit * 2;
        sum += (times_2 % 10) + (times_2 / 10);
        copy_c_c_n /= 100;
    }
    return (sum % 10 == 0);
}

int check_length(long long credit_card_number)
{
    int length = 0;
    while (credit_card_number != 0)
    {
        credit_card_number = credit_card_number / 10;
        length++;
    }
    return length;
}
