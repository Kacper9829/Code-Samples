while True:
    try:
        height = int(input("Height: "))
    except: ValueError
    else:
        if (height >= 1 and height <= 8):
            for brick in range(height):

                # print spaces on the left side
                print(" " * (height - brick - 1), end="")

                # print left side
                print("#" * (brick + 1), end="")

                # print space inbetween
                print("  ", end="")

                # print right side
                print("#" * (brick + 1), end="")

                # new line
                print()

            break

