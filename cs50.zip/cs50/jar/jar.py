import sys

class Jar:
    def __init__(self, capacity=12):
        self.max_capacity = capacity
        if self.capacity < 0:
            raise ValueError
        self.cookies_in_jar = 0

    def __str__(self):
        return "🍪"* self.cookies_in_jar

    def deposit(self, n):
        if self.cookies_in_jar + n > self.capacity:
            raise ValueError
        self.cookies_in_jar += n


    def withdraw(self, n):
        if self.cookies_in_jar - n < 0:
            raise ValueError
        self.cookies_in_jar -= n


    @property
    def capacity(self):
        return self.max_capacity

    @property
    def size(self):
        return self.cookies_in_jar

def main():
    jar = Jar()
    print(str(jar.capacity))
    print(str(jar))
    jar.deposit(5)
    print(str(jar))
    jar.withdraw(3)
    print(str(jar))



main()


