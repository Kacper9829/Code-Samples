-- Keep a log of any SQL queries you execute as you solve the mystery.
--Check the structure of tables and data
.schem
--Find crime report from 28th July on Humphrey Street
SELECT description FROM crime_scene_reports WHERE day = 28 AND month = 7 AND street = "Humphrey Street";
--Check bakery security logs and interviews
SELECT transcript FROM interviews WHERE day = 28 AND month = 7;
SELECT activity, license_plate, hour, minute FROM bakery_security_logs WHERE hour = 10 AND minute BETWEEN 15 AND 25 AND day = 28 AND month = 7;
--Check ATM data
SELECT account_number FROM atm_transactions WHERE month = 7 AND day = 28 AND atm_location = "Leggett Street" AND transaction_type = "withdraw";
--Find poeple ids macthcing account numbers
SELECT person_id FROM bank_accounts WHERE account_number IN(SELECT account_number FROM atm_transactions WHERE month = 7 AND day = 28 AND atm_location = "Leggett Street" AND transaction_type = "withdraw");
--Search for matching license plate matching bank accounts from ATM at Lagget Street and plates form baker survailence
SELECT license_plate
    FROM people
    JOIN bank_accounts
        ON people.id = bank_accounts.person_id
    WHERE person_id IN (
        SELECT person_id
        FROM bank_accounts
        WHERE account_number IN (
            SELECT account_number
                FROM atm_transactions
                WHERE month = 7
                    AND day = 28
                    AND atm_location = "Leggett Street"
                    AND transaction_type = "withdraw"
                    ))
        AND license_plate IN (
            SELECT license_plate
            FROM bakery_security_logs
            WHERE hour = 10
                AND minute BETWEEN 15
                AND 25 AND day = 28
                AND month = 7
                AND activity = "exit");


--Using license plates, search phone numbers and match them with calls made in 10 min span of the theft
 SELECT phone_number
    FROM people
    WHERE license_plate IN (
        SELECT license_plate
        FROM people
        JOIN bank_accounts
            ON people.id = bank_accounts.person_id
        WHERE person_id IN (
            SELECT person_id
            FROM bank_accounts
            WHERE account_number IN (
                SELECT account_number
                FROM atm_transactions
                WHERE month = 7
                    AND day = 28
                    AND atm_location = "Leggett Street"
                    AND transaction_type = "withdraw"
                                ))
                AND license_plate IN (
                    SELECT license_plate
                    FROM bakery_security_logs
                    WHERE hour = 10
                        AND minute BETWEEN 15 AND 25
                        AND day = 28
                        AND month = 7
                        AND activity = "exit"));
--Check if the found numbers are in the phone calls and get receiver number
SELECT receiver
    FROM phone_calls
    WHERE day = 28
        AND month = 7
        AND duration <= 60
        AND caller IN (
            SELECT phone_number
                FROM people
                WHERE license_plate IN (
                    SELECT license_plate
                    FROM people
                    JOIN bank_accounts
                        ON people.id = bank_accounts.person_id
                    WHERE person_id IN (
                        SELECT person_id
                        FROM bank_accounts
                        WHERE account_number IN (
                            SELECT account_number
                            FROM atm_transactions
                            WHERE month = 7
                                AND day = 28
                                AND atm_location = "Leggett Street"
                                AND transaction_type = "withdraw"
                                            ))
                            AND license_plate IN (
                                SELECT license_plate
                                FROM bakery_security_logs
                                WHERE hour = 10
                                    AND minute BETWEEN 15 AND 25
                                    AND day = 28
                                    AND month = 7
                                    AND activity = "exit")));
--Check flights on 29th of July
SELECT id, destination_airport_id FROM flights WHERE day = 29 AND month = 7 ORDER BY hour LIMIT 1;
--Check destiantion
SELECT full_name, city
    FROM airports
    JOIN flights
        ON airports.id = flights.destination_airport_id
    WHERE flights.destination_airport_id = (
       SELECT destination_airport_id
            FROM flights
            WHERE day = 29
                AND month = 7
            ORDER BY hour
            LIMIT 1
    );
--Get passengers info
SELECT *
    FROM passengers
    JOIN flights
        ON passengers.flight_id = flights.id
    WHERE id IN (
        SELECT id
            FROM flights
            WHERE day = 29
                AND month = 7
            ORDER BY hour
            LIMIT 1);
--Get phone numbers with passport numbers to match with the caller
SELECT phone_number
    FROM people
    WHERE passport_number IN(
        SELECT passport_number
            FROM passengers
            JOIN flights
                ON passengers.flight_id = flights.id
            WHERE id IN (
                SELECT id
                    FROM flights
                    WHERE day = 29
                        AND month = 7
                    ORDER BY hour
                    LIMIT 1));
--Match with caller number
SELECT receiver
    FROM phone_calls
    WHERE day = 28
        AND month = 7
        AND duration <= 60
        AND caller IN (
            SELECT phone_number
                FROM people
                WHERE license_plate IN (
                    SELECT license_plate
                    FROM people
                    JOIN bank_accounts
                        ON people.id = bank_accounts.person_id
                    WHERE person_id IN (
                        SELECT person_id
                        FROM bank_accounts
                        WHERE account_number IN (
                            SELECT account_number
                            FROM atm_transactions
                            WHERE month = 7
                                AND day = 28
                                AND atm_location = 'Leggett Street'
                                AND transaction_type = 'withdraw'
                                            ))
                            AND license_plate IN (
                                SELECT license_plate
                                FROM bakery_security_logs
                                WHERE hour = 10
                                    AND minute BETWEEN 15 AND 25
                                    AND day = 28
                                    AND month = 7
                                    AND activity = 'exit')))
    AND caller IN (
        SELECT phone_number
            FROM people
            WHERE passport_number IN(
                SELECT passport_number
                    FROM passengers
                    JOIN flights
                        ON passengers.flight_id = flights.id
                    WHERE flights.id = (
                        SELECT id
                            FROM flights
                            WHERE day = 29
                                AND month = 7
                            ORDER BY hour
                            LIMIT 1)));
-- Check personal information of the caller and receiver
SELECT name FROM people WHERE phone_number IN(
    SELECT receiver
        FROM phone_calls
        WHERE day = 28
            AND month = 7
            AND duration <= 60
            AND caller IN (
                SELECT phone_number
                    FROM people
                    WHERE license_plate IN (
                        SELECT license_plate
                        FROM people
                        JOIN bank_accounts
                            ON people.id = bank_accounts.person_id
                        WHERE person_id IN (
                            SELECT person_id
                            FROM bank_accounts
                            WHERE account_number IN (
                                SELECT account_number
                                FROM atm_transactions
                                WHERE month = 7
                                    AND day = 28
                                    AND atm_location = 'Leggett Street'
                                    AND transaction_type = 'withdraw'
                                                ))
                                AND license_plate IN (
                                    SELECT license_plate
                                    FROM bakery_security_logs
                                    WHERE hour = 10
                                        AND minute BETWEEN 15 AND 25
                                        AND day = 28
                                        AND month = 7
                                        AND activity = 'exit')))
        AND caller IN (
            SELECT phone_number
                FROM people
                WHERE passport_number IN(
                    SELECT passport_number
                        FROM passengers
                        JOIN flights
                            ON passengers.flight_id = flights.id
                        WHERE flights.id = (
                            SELECT id
                                FROM flights
                                WHERE day = 29
                                    AND month = 7
                                ORDER BY hour
                                LIMIT 1))));
--Caller aka the THIEF
SELECT name FROM people WHERE phone_number IN(
    SELECT caller
        FROM phone_calls
        WHERE day = 28
            AND month = 7
            AND duration <= 60
            AND caller IN (
                SELECT phone_number
                    FROM people
                    WHERE license_plate IN (
                        SELECT license_plate
                        FROM people
                        JOIN bank_accounts
                            ON people.id = bank_accounts.person_id
                        WHERE person_id IN (
                            SELECT person_id
                            FROM bank_accounts
                            WHERE account_number IN (
                                SELECT account_number
                                FROM atm_transactions
                                WHERE month = 7
                                    AND day = 28
                                    AND atm_location = 'Leggett Street'
                                    AND transaction_type = 'withdraw'
                                                ))
                                AND license_plate IN (
                                    SELECT license_plate
                                    FROM bakery_security_logs
                                    WHERE hour = 10
                                        AND minute BETWEEN 15 AND 25
                                        AND day = 28
                                        AND month = 7
                                        AND activity = 'exit')))
        AND caller IN (
            SELECT phone_number
                FROM people
                WHERE passport_number IN(
                    SELECT passport_number
                        FROM passengers
                        JOIN flights
                            ON passengers.flight_id = flights.id
                        WHERE flights.id = (
                            SELECT id
                                FROM flights
                                WHERE day = 29
                                    AND month = 7
                                ORDER BY hour
                                LIMIT 1))));
