#include "helpers.h"
#include <math.h>

// Convert image to grayscale
void grayscale(int height, int width, RGBTRIPLE image[height][width])
{
    // go through every pixel
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            // calculate average
            int avg =
                round(((image[i][j].rgbtRed + image[i][j].rgbtGreen + image[i][j].rgbtBlue) / 3.0));
            image[i][j].rgbtRed = avg;
            image[i][j].rgbtGreen = avg;
            image[i][j].rgbtBlue = avg;
        }
    }
}

// Convert image to sepia
void sepia(int height, int width, RGBTRIPLE image[height][width])
{
    // go through every pixel
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            // set copies of each color
            int original_red = image[i][j].rgbtRed;
            int original_green = image[i][j].rgbtGreen;
            int original_blue = image[i][j].rgbtBlue;
            // apply sepia algorithm
            int sepia_red =
                round(.393 * original_red + .769 * original_green + .189 * original_blue);
            int sepia_green =
                round(.349 * original_red + .686 * original_green + .168 * original_blue);
            int sepia_blue =
                round(.272 * original_red + .534 * original_green + .131 * original_blue);

            if (sepia_red > 255)
            {
                image[i][j].rgbtRed = 255;
            }
            else
            {
                image[i][j].rgbtRed = sepia_red;
            }
            if (sepia_green > 255)
            {
                image[i][j].rgbtGreen = 255;
            }
            else
            {
                image[i][j].rgbtGreen = sepia_green;
            }
            if (sepia_blue > 255)
            {
                image[i][j].rgbtBlue = 255;
            }
            else
            {
                image[i][j].rgbtBlue = sepia_blue;
            }
        }
    }
}

// Reflect image horizontally
void reflect(int height, int width, RGBTRIPLE image[height][width])
{
    // find middle point of the row
    int middle = width / 2;
    // set temporary variable
    RGBTRIPLE temp;
    // go through every pixel
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < middle; j++)
        {
            // change values
            temp = image[i][j];
            image[i][j] = image[i][width - 1 - j];
            image[i][width - 1 - j] = temp;
        }
    }
}

// Blur image
void blur(int height, int width, RGBTRIPLE image[height][width])
{
    // set up copy of the image
    RGBTRIPLE copy[height][width];
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            copy[i][j] = image[i][j];
        }
    }

    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            // set sums of every color
            float sum_red = 0;
            float sum_green = 0;
            float sum_blue = 0;
            // set counter of neighbours
            int count = 0;
            // go through all the neighbours
            for (int column = -1; column <= 1; column++)
            {
                for (int row = -1; row <= 1; row++)
                {
                    int neighbour_i = i + column;
                    int neighbour_j = j + row;
                    // check for the boundries
                    if (neighbour_i >= 0 && neighbour_i < height && neighbour_j >= 0 &&
                        neighbour_j < width)
                    {
                        // sum colores of the neighbour
                        sum_red += copy[neighbour_i][neighbour_j].rgbtRed;
                        sum_green += copy[neighbour_i][neighbour_j].rgbtGreen;
                        sum_blue += copy[neighbour_i][neighbour_j].rgbtBlue;
                        count++;
                    }
                }
            }
            // apply new colors to original image
            image[i][j].rgbtRed = round(sum_red / count);
            image[i][j].rgbtGreen = round(sum_green / count);
            image[i][j].rgbtBlue = round(sum_blue / count);
        }
    }
}
