CREATE students (
    id integer,
    name TEXT,
    house TEXT,
    head TEXT,
    PRIMARY KEY(id)
);

CREATE house (
    id integer,
    house_name TEXT,
    head TEXT,
    student_id integer,
    PRIMARY KEY(id),
    FOREIGN KEY(student_id) REFERENCES studnets(id)

);
CREATE house_assigments (
    house_id integer,
    student_id integer,
    FOREIGN KEY(house_id) REFERENCES house(id)
    FOREIGN KEY(student_id) REFERENCES studnets(id)

);

