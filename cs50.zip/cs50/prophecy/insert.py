import sqlite3
import csv


connection = sqlite3.connect("Hogwarts.db")
crsr = connection.cursor()

student_table = """CREATE TABLE students (
    id integer PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    house TEXT,
    head TEXT
);"""

house_table ="""CREATE TABLE house (
    id integer PRIMARY KEY AUTOINCREMENT,
    house_name TEXT UNIQUE,
    head TEXT
);"""

house_assigment_table ="""CREATE TABLE house_assigments (
    house_id integer,
    student_id integer,
    FOREIGN KEY(house_id) REFERENCES house(id),
    FOREIGN KEY(student_id) REFERENCES students(id)
);
"""

crsr.execute(student_table)
crsr.execute(house_table)
crsr.execute(house_assigment_table)

with open("students.csv", newline = "", encoding="utf-8") as file:
    reader = csv.DictReader(file)
    for row in reader:
        crsr.execute(
            "INSERT INTO students (name, house, head) VALUES (?, ?, ?)",
            (row["student_name"], row["house"], row["head"])
            )
        student_id = crsr.lastrowid

        crsr.execute(
            "INSERT OR IGNORE INTO house (house_name, head) VALUES (?, ?)",
            (row["house"], row["head"])
        )
        crsr.execute("SELECT id FROM house WHERE house_name = ?", (row["house"],))
        house_id = crsr.fetchone()[0]



        crsr.execute(
            "INSERT INTO house_assigments (house_id, student_id) VALUES (?, ?)",
            (house_id, student_id)
        )



connection.commit()

connection.close()
