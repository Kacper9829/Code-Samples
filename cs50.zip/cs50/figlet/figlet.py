import sys
from random import choice
from pyfiglet import Figlet

def figlet_font_change():
    args = sys.argv
    figlet = Figlet()
    fonts = figlet.getFonts()

    if len(args) not in [1, 3]:
        print("Invalid usage ")
        sys.exit(1)
    elif args[1] != "-f":
        print("Invalid usage ")
        sys.exit(2)
    else:
        text = input("Enter text to change the font: ")

        if len(args) == 3:
            figlet.setFont(font = args[2])
            print(figlet.renderText(text))
        else:
            figlet.setFont(font = choice(fonts))
            print(figlet.renderText(text))



figlet_font_change()
